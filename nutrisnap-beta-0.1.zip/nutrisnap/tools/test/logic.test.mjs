import { calcTargets, sumMeal, macrosFor } from './build/nutrition.js';
import { parseFoods, processChatMessage } from './build/chat.js';
import { getWeekPlan, getTodaySession, getCoachNote } from './build/training.js';
import { exercisesFor } from './build/exercises.js';
import { currentStreak, nextStreak, dayKey, createId } from './build/storage.js';
import { FOODS, FOODS_BY_ID } from './build/data.js';

let pass = 0, fail = 0;
const t = (name, fn) => {
  try { fn(); console.log(`  ✓ ${name}`); pass++; }
  catch (e) { console.log(`  ✗ ${name}\n      ${e.message}`); fail++; }
};
const eq = (a, b, m) => { if (a !== b) throw new Error(`${m ?? ''} esperado ${b}, obtenido ${a}`); };
const ok = (c, m) => { if (!c) throw new Error(m ?? 'falso'); };

const base = {
  gender: 'hombre', bodyType: 'normal', goal: 'mantener', dietNotes: '',
  logFrequency: 'cada-comida', trainingFrequency: '3-4', workoutMode: 'gimnasio',
  createdAt: new Date().toISOString(),
};

console.log('\n── Motor nutricional ──');

t('cubre toda la matriz sin producir macros imposibles', () => {
  let n = 0;
  for (const gender of ['hombre','mujer'])
  for (const bodyType of ['delgado','normal','sobrepeso'])
  for (const goal of ['perder-grasa','mantener','ganar-musculo'])
  for (const trainingFrequency of ['ninguno','1-2','3-4','5-6','diario'])
  for (const [age,weightKg,heightCm] of [[undefined,undefined,undefined],[18,50,150],[30,75,175],[65,120,190],[25,300,230],[25,30,120]]) {
    const r = calcTargets({ ...base, gender, bodyType, goal, trainingFrequency, age, weightKg, heightCm });
    ok(r.calories > 0, 'calorías no positivas');
    ok(r.protein > 0 && r.carbs > 0 && r.fat > 0, `macro en cero: ${JSON.stringify(r)}`);
    const fromMacros = r.protein*4 + r.carbs*4 + r.fat*9;
    ok(Math.abs(fromMacros - r.calories) <= 12, `macros ${fromMacros} vs kcal ${r.calories}`);
    n++;
  }
  console.log(`      (${n} combinaciones)`);
});

t('nunca baja del mínimo seguro', () => {
  const r = calcTargets({ ...base, gender:'mujer', bodyType:'delgado', goal:'perder-grasa',
    trainingFrequency:'ninguno', age:70, weightKg:40, heightCm:145 });
  ok(r.calories >= 1200, `${r.calories} kcal por debajo del piso`);
  ok(r.notes.includes('minimo-seguro'), 'no avisó del ajuste');
});

t('menor de edad recibe mantenimiento', () => {
  const kid = calcTargets({ ...base, goal:'perder-grasa', age:15, weightKg:60, heightCm:168 });
  const adult = calcTargets({ ...base, goal:'mantener', age:15, weightKg:60, heightCm:168 });
  eq(kid.calories, adult.calories, 'déficit aplicado a un menor:');
  ok(kid.notes.includes('menor-de-edad'), 'sin aviso');
});

t('los objetivos se ordenan como corresponde', () => {
  const p = { ...base, age:30, weightKg:75, heightCm:175 };
  const perder = calcTargets({...p, goal:'perder-grasa'}).calories;
  const mant   = calcTargets({...p, goal:'mantener'}).calories;
  const ganar  = calcTargets({...p, goal:'ganar-musculo'}).calories;
  ok(perder < mant && mant < ganar, `${perder} / ${mant} / ${ganar}`);
});

console.log('\n── Base de alimentos ──');

t('sin ids duplicados y macros coherentes con las kcal', () => {
  eq(new Set(FOODS.map(f=>f.id)).size, FOODS.length, 'ids duplicados:');
  for (const f of FOODS) {
    const calc = f.protein*4 + f.carbs*4 + f.fat*9;
    ok(Math.abs(calc - f.kcal) <= Math.max(f.kcal*0.22, 12),
       `${f.name}: macros dan ${calc.toFixed(0)} pero declara ${f.kcal}`);
    ok(f.portionG > 0, `${f.name} sin ración`);
  }
});

console.log('\n── Parser del chat ──');

t('la frase del brief se interpreta entera', () => {
  const r = parseFoods('Me comí dos huevos revueltos con una tostada y un café con leche');
  const ids = r.map(x=>x.food.id);
  ok(ids.includes('huevo'), `sin huevo: ${ids}`);
  ok(ids.includes('pan-integral'), `sin tostada: ${ids}`);
  ok(ids.includes('cafe-con-leche'), `sin café con leche: ${ids}`);
  const huevo = r.find(x=>x.food.id==='huevo');
  eq(huevo.grams, 100, 'dos huevos (50 g c/u):');
});

t('"café con leche" no se degrada a "café"', () => {
  const ids = parseFoods('un café con leche').map(x=>x.food.id);
  ok(ids.includes('cafe-con-leche') && !ids.includes('cafe-negro'), ids.join());
});

t('unidades de masa explícitas', () => {
  const r = parseFoods('150 g de pollo con 200 gramos de arroz');
  eq(r.find(x=>x.food.id==='pollo-pechuga').grams, 150);
  eq(r.find(x=>x.food.id==='arroz-blanco').grams, 200);
});

t('acentos, plurales y medios', () => {
  eq(parseFoods('platano').length, 1, 'sin tilde:');
  eq(parseFoods('dos arepas')[0].grams, 160, 'dos arepas de 80 g:');
  eq(parseFoods('media arepa')[0].grams, 40, 'media arepa:');
});

t('texto sin comida no inventa alimentos', () => {
  eq(parseFoods('hola qué tal, buenos días').length, 0);
});

console.log('\n── Respuestas del chat ──');
const targets = calcTargets({ ...base, age:30, weightKg:75, heightCm:175 });
const zero = { calories:0, protein:0, carbs:0, fat:0 };

const chatProfile = {...base, age:30, weightKg:75, heightCm:175};
const chatCases = [
  ['registra una comida', 'Almorcé arroz con pollo', r => ok(r.meal && r.meal.totals.calories>0, 'sin comida adjunta')],
  ['responde a una consulta', '¿Cuántas calorías tiene el aguacate?', r => ok(r.text.includes('kcal'), r.text)],
  ['sugiere merienda', 'Tengo hambre, ¿qué merienda me recomiendas?', r => ok(r.text.length>40 && !r.meal, r.text)],
  ['sugiere ejercicio', '¿Qué rutina me toca hoy?', r => ok(!r.meal && r.text.length>30, r.text)],
  ['cae en ayuda', 'aksjdhaskjdh', r => ok(r.text.includes('Puedo ayudarte'), r.text)],
];
for (const [name, msg, check] of chatCases) {
  try {
    const r = await processChatMessage(msg, chatProfile, targets, zero);
    check(r); console.log(`  ✓ ${name}`); pass++;
  } catch (e) { console.log(`  ✗ ${name}\n      ${e.message}`); fail++; }
}

console.log('\n── Entrenamiento ──');

t('toda frecuencia genera 7 días con ejercicios reales', () => {
  for (const trainingFrequency of ['ninguno','1-2','3-4','5-6','diario'])
  for (const goal of ['perder-grasa','mantener','ganar-musculo'])
  for (const workoutMode of ['gimnasio','calistenia']) {
    const week = getWeekPlan({ ...base, trainingFrequency, goal, workoutMode });
    eq(week.length, 7, `${trainingFrequency}/${goal}:`);
    for (const s of week) {
      ok(s.title && s.focus, 'sesión sin título o foco');
      if (s.type !== 'descanso') {
        const ex = exercisesFor(s.type, workoutMode);
        ok(ex.length > 0, `${s.type} en ${workoutMode} se queda sin ejercicios`);
      }
    }
  }
});

t('perder grasa mete un bloque de alta intensidad', () => {
  const week = getWeekPlan({ ...base, goal:'perder-grasa', trainingFrequency:'3-4' });
  ok(week.some(s=>s.type==='hiit'), week.map(s=>s.type).join());
});

t('la sesión de hoy pertenece a la semana', () => {
  const p = { ...base };
  ok(getWeekPlan(p).some(s => s.title === getTodaySession(p).title));
});

t('la nota del entrenador reacciona a la proteína baja', () => {
  const p = { ...base, age:30, weightKg:75, heightCm:175 };
  const s = getTodaySession(p);
  if (s.type === 'descanso') return;
  const low = getCoachNote(p, targets, { calories:2000, protein:20, carbs:200, fat:60 }, s);
  ok(low.includes('proteína'), low);
});

console.log('\n── Rachas y utilidades ──');

t('la racha caduca al saltarse días', () => {
  const hoy = dayKey();
  const ayer = dayKey(new Date(Date.now()-86400000));
  const hace4 = dayKey(new Date(Date.now()-4*86400000));
  eq(currentStreak(5, hoy), 5, 'registró hoy:');
  eq(currentStreak(5, ayer), 5, 'registró ayer (aún viva):');
  eq(currentStreak(5, hace4), 0, 'hace 4 días:');
  eq(currentStreak(5, null), 0, 'sin registros:');
});

t('nextStreak encadena y reinicia', () => {
  const ayer = dayKey(new Date(Date.now()-86400000));
  eq(nextStreak(3, ayer), 4, 'encadenar:');
  eq(nextStreak(3, dayKey()), 3, 'mismo día:');
  eq(nextStreak(3, dayKey(new Date(Date.now()-5*86400000))), 1, 'reiniciar:');
});

t('createId genera valores únicos', () => {
  const s = new Set(Array.from({length:2000}, createId));
  eq(s.size, 2000, 'colisión:');
});

t('sumMeal cuadra con macrosFor', () => {
  const items = [
    { foodId:'pollo-pechuga', name:'', emoji:'', grams:150 },
    { foodId:'arroz-blanco', name:'', emoji:'', grams:180 },
  ];
  const total = sumMeal(items);
  const manual = items.reduce((a,i)=>a+macrosFor(FOODS_BY_ID[i.foodId], i.grams).calories, 0);
  ok(Math.abs(total.calories - manual) <= 1, `${total.calories} vs ${manual}`);
});

t('un alimento inexistente no rompe la suma', () => {
  const r = sumMeal([{ foodId:'no-existe', name:'', emoji:'', grams:100 }]);
  eq(r.calories, 0);
});

console.log(`\n${'─'.repeat(46)}\n  ${pass} pasan · ${fail} fallan\n`);
process.exit(fail ? 1 : 0);
