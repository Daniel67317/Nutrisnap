#!/usr/bin/env bash
# Compila los módulos de lógica pura y ejecuta las aserciones con Node.
# No necesita npm install: sólo `tsc` y `node`.
set -e
cd "$(dirname "$0")/../.."
TMP=$(mktemp -d)
cp -r src "$TMP/"
cat > "$TMP/tsconfig.json" <<'JSON'
{
  "compilerOptions": {
    "target": "ES2022", "module": "ES2022", "moduleResolution": "bundler",
    "lib": ["ES2022", "DOM"], "outDir": "build", "rootDir": "src/lib",
    "skipLibCheck": true, "strict": true, "types": []
  },
  "include": ["src/lib/types.ts","src/lib/data.ts","src/lib/nutrition.ts","src/lib/chat.ts",
              "src/lib/training.ts","src/lib/exercises.ts","src/lib/storage.ts",
              "src/lib/access.ts","src/lib/vision.ts"]
}
JSON
npx tsc -p "$TMP/tsconfig.json"
# Node en ESM exige la extensión explícita en los imports relativos
find "$TMP/build" -name '*.js' -exec sed -i -E "s|from '\./([a-zA-Z]+)'|from './\1.js'|g" {} +
cp tools/test/logic.test.mjs "$TMP/test.mjs"
cd "$TMP" && node test.mjs
